@echo off
setlocal EnableExtensions
set "REPO_URL=https://github.com/ap1-star/gate-ec-intel.git"
set "TARGET_DIR=%~dp0gate-ec-intel"

echo GATE EC Research Terminal - GitHub Upload
 echo Destination: %REPO_URL%
echo.
where git >nul 2>nul
if errorlevel 1 (
  echo ERROR: Git for Windows is not installed or is not on PATH.
  echo Install Git from https://git-scm.com/downloads/win
  goto :fail
)
if not exist "%TARGET_DIR%\package.json" (
  echo ERROR: Project folder missing. Extract the ENTIRE upload kit first.
  goto :fail
)
cd /d "%TARGET_DIR%" || goto :fail
if not exist ".git\config" (
  git init -b main || goto :fail
)
for /f "delims=" %%A in ('git remote get-url origin 2^>nul') do set "EXISTING_REMOTE=%%A"
if defined EXISTING_REMOTE (
  if /I not "%EXISTING_REMOTE%"=="%REPO_URL%" (
    echo ERROR: Existing git origin points somewhere else: %EXISTING_REMOTE%
    echo Refusing to modify that repository.
    goto :fail
  )
) else (
  git remote add origin "%REPO_URL%" || goto :fail
)
for /f "delims=" %%B in ('git branch --show-current') do set "CURRENT_BRANCH=%%B"
if defined CURRENT_BRANCH if /I not "%CURRENT_BRANCH%"=="main" (
  echo ERROR: Current branch is not main. Refusing to push another branch.
  goto :fail
)
git add -A || goto :fail
git diff --cached --quiet
if errorlevel 1 (
  git commit -m "Initial GATE EC Research Terminal hosting source" || (
    echo Git commit failed. If Git asks for identity, configure your Git name and email.
    goto :fail
  )
) else (
  echo No new changes to commit.
)
git push --set-upstream origin main || goto :fail
echo.
echo SUCCESS: Check https://github.com/ap1-star/gate-ec-intel
pause
exit /b 0
:fail
echo.
echo Git upload did not complete. No force push was attempted.
pause
exit /b 1
