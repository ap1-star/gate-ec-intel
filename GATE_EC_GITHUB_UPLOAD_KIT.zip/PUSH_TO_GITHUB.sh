#!/usr/bin/env bash
set -euo pipefail
repo="https://github.com/ap1-star/gate-ec-intel.git"
cd "$(dirname "$0")/gate-ec-intel"
command -v git >/dev/null || { echo 'Install Git first.'; exit 1; }
[[ -d .git ]] || git init -b main
old=$(git remote get-url origin 2>/dev/null || true)
if [[ -n "$old" && "$old" != "$repo" ]]; then echo "Origin mismatch: $old"; exit 1; fi
[[ -n "$old" ]] || git remote add origin "$repo"
branch=$(git branch --show-current)
[[ -z "$branch" || "$branch" == main ]] || { echo "Wrong branch: $branch"; exit 1; }
git add -A
if ! git diff --cached --quiet; then git commit -m 'Initial GATE EC Research Terminal hosting source'; fi
git push -u origin main
printf '
Uploaded to https://github.com/ap1-star/gate-ec-intel
'
