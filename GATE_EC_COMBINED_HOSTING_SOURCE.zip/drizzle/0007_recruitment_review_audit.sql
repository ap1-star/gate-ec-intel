-- Immutable owner review evidence; no approval or candidate seed records.
CREATE TABLE recruitment_review_audits (id TEXT PRIMARY KEY,notice_id TEXT NOT NULL REFERENCES recruitment_notices(id),actor_id TEXT REFERENCES users(id) ON DELETE SET NULL,source_url TEXT NOT NULL,source_content_hash TEXT,previous_version INTEGER NOT NULL,approved_version INTEGER NOT NULL,previous_payload_hash TEXT NOT NULL,approved_payload_hash TEXT NOT NULL,attestation_json TEXT NOT NULL,posts_snapshot_json TEXT NOT NULL,created_at TEXT NOT NULL);
--> statement-breakpoint
CREATE INDEX recruitment_review_notice_idx ON recruitment_review_audits(notice_id,created_at);
--> statement-breakpoint
CREATE TRIGGER recruitment_review_immutable_update BEFORE UPDATE ON recruitment_review_audits WHEN NOT (OLD.actor_id IS NOT NULL AND NEW.actor_id IS NULL AND NEW.id IS OLD.id AND NEW.notice_id IS OLD.notice_id AND NEW.source_url IS OLD.source_url AND NEW.source_content_hash IS OLD.source_content_hash AND NEW.previous_version IS OLD.previous_version AND NEW.approved_version IS OLD.approved_version AND NEW.previous_payload_hash IS OLD.previous_payload_hash AND NEW.approved_payload_hash IS OLD.approved_payload_hash AND NEW.attestation_json IS OLD.attestation_json AND NEW.posts_snapshot_json IS OLD.posts_snapshot_json AND NEW.created_at IS OLD.created_at) BEGIN SELECT RAISE(ABORT,'Recruitment review audit rows are immutable'); END;
--> statement-breakpoint
CREATE TRIGGER recruitment_review_immutable_delete BEFORE DELETE ON recruitment_review_audits BEGIN SELECT RAISE(ABORT,'Recruitment review audit rows are immutable'); END;
--> statement-breakpoint
